//
//  ViewController.swift
//  F2F
//
//  Created by MITLAB on 2016/7/29.
//  Copyright © 2016年 MITLAB. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var WebView: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = NSURL(string: "http://140.118.122.246/f2f/mobile")
        let request = NSURLRequest(URL: url!)
        WebView.loadRequest(request)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

